// Define your array of objects with questions, choices, and correct answers
const questions = [
    {
      question: "What does HTML stand for?",
      choices: ["Hyper Text Markup Language", "Hyperlinks and Text Markup Language", "Home Tool Markup Language", "Hyper Text Markup Leveler"],
      correctAnswer: "Hyper Text Markup Language"
    },
    {
      question: "What is the correct HTML element for the largest heading?",
      choices: ["<h1>", "<heading>", "<head>", "<h6>"],
      correctAnswer: "<h1>"
    },
    // Add more questions here
  ];
  
  let currentQuestionIndex = 0;
  let score = 0;
  
  // Function to display the current question and choices
  function displayQuestion() {
    const questionElement = document.getElementById("question");
    const choicesElement = document.getElementById("choices");
    
    // Display the current question
    questionElement.textContent = questions[currentQuestionIndex].question;
    
    // Clear the previous choices
    choicesElement.innerHTML = "";
    
    // Display the choices for the current question
    questions[currentQuestionIndex].choices.forEach(choice => {
      const li = document.createElement("li");
      li.textContent = choice;
      choicesElement.appendChild(li);
    });
  }
  
  // Function to check if the selected answer is correct
  function checkAnswer(selectedAnswer) 
    if (selectedAnswer === questions[currentQuestionIndex].correctAnswer) {
      score++;
    }
    
    // Move on to the next question
    currentQuestionIndex++;
    
    // Check if all questions have been answered
    if (currentQuestionIndex === questions.length) {
      // Display the final score
      alert("Your final score is: " + score + "/")
    }